from matplotlib import pyplot as plt
import matplotlib
import os
import random
import torch
import numpy as np
import cv2
from torch.autograd import Variable
import torchvision.transforms as standard_transforms
import misc.transforms as own_transforms
import pandas as pd
import pytest
from models.CC import CrowdCounter
from config import cfg
from misc.utils import *
import scipy.io as sio
from PIL import Image, ImageOps
from qualitycc import calc_psnr, calc_ssim
from skimage.feature import peak_local_max
from scipy import ndimage as ndi
from skimage.segmentation import watershed
import torch.nn.functional as F
from sklearn.cluster import DBSCAN
from scipy.spatial import distance

torch.cuda.set_device(0)
torch.backends.cudnn.benchmark = True

mean_std = ([0.4581805467605591, 0.4938826858997345, 0.267184853553772],
            [0.22368745505809784, 0.195216104388237, 0.23709380626678467])
img_transform = standard_transforms.Compose([
    standard_transforms.ToTensor(),
    standard_transforms.Normalize(*mean_std)
])

dot_transform = standard_transforms.Compose([
    standard_transforms.ToTensor(),
    own_transforms.tensormul(255.0)
])
mask_transform = standard_transforms.Compose([
    standard_transforms.ToTensor(),
])
restore = standard_transforms.Compose([
    own_transforms.DeNormalize(*mean_std),
    standard_transforms.ToPILImage()
])
pil_to_tensor = standard_transforms.ToTensor()
LOG_PARA = 100.0

dataRoot = ''

model_path = ''
new_filename = ''

os.makedirs('pred1/' + new_filename, exist_ok=True)
os.makedirs('pred1/' + new_filename + '_mask', exist_ok=True)
os.makedirs('pred1/' + new_filename + '_instances', exist_ok=True)
os.makedirs('pred1/' + new_filename + '_results', exist_ok=True)
os.makedirs('pred1/' + new_filename + '_gt_images', exist_ok=True)


def postprocess_cluster_counting(density_map, segmentation_map, min_area=1000, max_clusters=3):

    binary_mask = (segmentation_map > 0.5).astype(np.uint8)
    if np.sum(binary_mask) == 0:
        return [], [], np.zeros_like(binary_mask)
    kernel = np.ones((15, 15), np.uint8)
    cleaned_mask = cv2.morphologyEx(binary_mask, cv2.MORPH_CLOSE, kernel)
    cleaned_mask = cv2.morphologyEx(cleaned_mask, cv2.MORPH_OPEN, kernel)

    contours, _ = cv2.findContours(cleaned_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    large_contours = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if area >= min_area:
            large_contours.append(contour)

    if not large_contours:
        min_area = min_area // 2
        for contour in contours:
            area = cv2.contourArea(contour)
            if area >= min_area:
                large_contours.append(contour)

    if not large_contours:
        return [], [], np.zeros_like(binary_mask)

    centers = []
    for contour in large_contours:
        M = cv2.moments(contour)
        if M["m00"] != 0:
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
            centers.append((cx, cy))

    if len(centers) > 1:
        dist_matrix = distance.cdist(centers, centers, 'euclidean')

        clustering = DBSCAN(eps=50, min_samples=1).fit(centers)
        labels = clustering.labels_

        clusters = {}
        for i, label in enumerate(labels):
            if label not in clusters:
                clusters[label] = []
            clusters[label].append(large_contours[i])
    else:
        clusters = {0: large_contours}
    if len(clusters) > max_clusters:
        cluster_areas = []
        for label, cluster_contours in clusters.items():
            total_area = sum(cv2.contourArea(contour) for contour in cluster_contours)
            cluster_areas.append((label, total_area))
        cluster_areas.sort(key=lambda x: x[1], reverse=True)
        selected_clusters = {}
        for i in range(min(max_clusters, len(cluster_areas))):
            label, _ = cluster_areas[i]
            selected_clusters[label] = clusters[label]

        clusters = selected_clusters
    instance_masks = []
    berry_counts = []
    labeled_clusters = np.zeros_like(binary_mask, dtype=np.int32)

    for cluster_id, cluster_contours in clusters.items():
        cluster_mask = np.zeros_like(binary_mask, dtype=np.uint8)
        cv2.drawContours(cluster_mask, cluster_contours, -1, 1, thickness=cv2.FILLED)
        region_density = density_map * cluster_mask
        berry_count = np.sum(region_density)
        instance_masks.append(cluster_mask.astype(np.float32))
        berry_counts.append(berry_count)
        labeled_clusters[cluster_mask > 0] = cluster_id + 1

    return instance_masks, berry_counts, labeled_clusters


def save_density_map_with_text(density_map, filename, pred_count, gt_count, psnr, ssim, output_dir):

    fig, ax = plt.subplots(1, 1, figsize=(10, 8))
    im = ax.imshow(density_map, cmap='jet')
    font_prop = {'family': 'Times New Roman', 'size': 16, 'weight': 'bold'}
    text_str = f'Pred={int(round(pred_count))}'
    ax.text(0.02, 0.98, text_str, transform=ax.transAxes, fontdict=font_prop,
            verticalalignment='top', color='red',
            bbox=dict(boxstyle='round,pad=0.5', facecolor='white', alpha=1.0,
                      edgecolor='black', linewidth=1))
    ax.axis('off')
    plt.subplots_adjust(left=0, right=1, top=1, bottom=0)
    if psnr == 'NaN':
        save_filename = f'[{filename}]_[{int(round(pred_count))}_{int(round(gt_count))}]_[{psnr}]_[{ssim:.4f}].png'
    else:
        save_filename = f'{filename}_{int(round(pred_count))}_{int(round(gt_count))}_{psnr:.2f}_{ssim:.4f}.png'

    plt.savefig(os.path.join(output_dir, save_filename),
                dpi=150, bbox_inches='tight', pad_inches=0)
    plt.close(fig)


def save_gt_image_with_text(original_image, filename, gt_count, output_dir):
    fig, ax = plt.subplots(1, 1, figsize=(10, 8))

    if isinstance(original_image, Image.Image):
        ax.imshow(np.array(original_image))
    else:
        ax.imshow(original_image)

    font_prop = {'family': 'Times New Roman', 'size': 16, 'weight': 'bold'}
    text_str = f'GT={int(round(gt_count))}'
    ax.text(0.02, 0.98, text_str, transform=ax.transAxes, fontdict=font_prop,
            verticalalignment='top', color='red',
            bbox=dict(boxstyle='round,pad=0.5', facecolor='white', alpha=1.0,
                      edgecolor='black', linewidth=1))
    ax.axis('off')
    plt.subplots_adjust(left=0, right=1, top=1, bottom=0)
    save_filename = f'{filename}_GT_{int(round(gt_count))}.png'
    plt.savefig(os.path.join(output_dir, save_filename),
             dpi=150, bbox_inches='tight', pad_inches=0)
    plt.close(fig)


def main():
    txtpath = os.path.join(dataRoot, 'txt_list', 'val.txt')
    with open(txtpath) as f:
        lines = f.readlines()

    ceshi(lines, model_path)


def ceshi(file_list, model_path):
    net = CrowdCounter(cfg.GPU_ID, new_filename)
    net.cuda()
    net.load_state_dict(torch.load(model_path))
    net.eval()

    results_file = open(f'pred1/{new_filename}_results/cluster_counts.csv', 'w')
    results_file.write("Filename,Total_Berries,Cluster_Count,Cluster_ID,Berry_Count\n")

    for infos in file_list:
        filename = infos.split()[0]
        print(f"Processing {filename}...")

        imgname = os.path.join(dataRoot, 'img', filename + '.jpg')
        img = Image.open(imgname)

        dotname = imgname.replace('img', 'dot').replace('jpg', 'png')
        dot_map = Image.open(dotname)
        dot_map = dot_transform(dot_map)
        if img.mode == 'L':
            img = img.convert('RGB')
        img = img_transform(img)[None, :, :, :]
        dot_map = dot_map[None, :, :, :]
        mask_map = torch.zeros_like(dot_map)

        with torch.no_grad():
            img = Variable(img).cuda()
            dot_map = Variable(dot_map).cuda()
            mask_map = Variable(mask_map).cuda()
            algt = torch.sum(dot_map).item()
            pred_map, pred_mask, den_map, _ = net.predict(img, dot_map, mask_map)
            pred_map_dot = pred_map / LOG_PARA
            pred_dot = torch.sum(pred_map_dot).item()
            pred_map_mask = torch.sigmoid(pred_mask)

        pred_map_dot_np = pred_map_dot.cpu().data.numpy()[0, 0, :, :]
        pred_map_mask_np = pred_map_mask.cpu().data.numpy()[0, 0, :, :]
        den_map_np = den_map.cpu().data.numpy()[0, 0, :, :]
        psnr = calc_psnr(den_map_np, pred_map_dot_np)
        ssim = calc_ssim(den_map_np, pred_map_dot_np)

        save_density_map_with_text(
            pred_map_dot_np,
            filename,
            pred_dot,
            algt,
            psnr,
            ssim,
            '' + new_filename
        )

        original_img = Image.open(imgname)
        save_gt_image_with_text(
            original_img,
            filename,
            algt,
            '' + new_filename + '_gt_images'
        )

        fig, ax = plt.subplots(1, 1, figsize=(10, 8))
        ax.imshow(pred_map_mask_np, cmap='gray')
        ax.axis('off')
        plt.subplots_adjust(left=0, right=1, top=1, bottom=0)
        plt.savefig(os.path.join('' + new_filename + '_mask',
                                 f'{filename}_mask.png'),
                    dpi=150, bbox_inches='tight', pad_inches=0)
        plt.close(fig)

        instance_masks, berry_counts, labeled_clusters = postprocess_cluster_counting(
            pred_map_dot_np, pred_map_mask_np, min_area=20000, max_clusters=3
        )

        fig, ax = plt.subplots(1, 1, figsize=(10, 8))
        ax.imshow(labeled_clusters, cmap='nipy_spectral')
        ax.axis('off')
        plt.subplots_adjust(left=0, right=1, top=1, bottom=0)
        plt.savefig(os.path.join('' + new_filename + '_instances',
                                 f'{filename}_instances.png'),
                    dpi=150, bbox_inches='tight', pad_inches=0)
        plt.close(fig)

        total_berries = sum(berry_counts)
        cluster_count = len(berry_counts)

        for i, count in enumerate(berry_counts):
            results_file.write(f"{filename},{int(round(total_berries))},{cluster_count},{i + 1},{int(round(count))}\n")

        fig, ax = plt.subplots(1, 1, figsize=(10, 8))

        ax.imshow(labeled_clusters, cmap='nipy_spectral')
        ax.axis('off')

        font_prop = {'family': 'Times New Roman', 'size': 14, 'weight': 'bold'}

        for i, (mask, count) in enumerate(zip(instance_masks, berry_counts)):

            y, x = ndi.center_of_mass(mask)

            ax.text(x, y, f'Pred={int(round(count))}',
                    fontsize=12, color='red', fontfamily='Times New Roman',
                    ha='center', va='center',
                    bbox=dict(boxstyle="round,pad=0.3", facecolor='white', edgecolor='red',
                              linewidth=2, alpha=0.9))

        plt.subplots_adjust(left=0, right=1, top=1, bottom=0)

        plt.savefig(os.path.join('D:/NWPU-Crowd-Sample-Code-master/pred1/' + new_filename + '_results',
                                 f'{filename}_results.png'),
                    dpi=150, bbox_inches='tight', pad_inches=0)
        plt.close(fig)

        print(
            f"Processed {filename}: Total Berries={int(round(pred_dot))}, Clusters={cluster_count}, GT={int(round(algt))}")

    results_file.close()


if __name__ == '__main__':
    main()