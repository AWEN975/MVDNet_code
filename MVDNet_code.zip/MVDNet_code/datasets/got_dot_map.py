import os
import json
from PIL import Image
import numpy as np


def get_dot_map(im_shape, points):
    dot_map = np.zeros(im_shape, dtype=int)

    if len(points) == 0:
        return dot_map
    points = np.asarray(points, dtype=int)
    valid_indices = (points[:, 0] >= 0) & (points[:, 0] < dot_map.shape[1]) & \
                    (points[:, 1] >= 0) & (points[:, 1] < dot_map.shape[0])

    dot_map[points[valid_indices, 1], points[valid_indices, 0]] += 1

    return dot_map

if __name__ == '__main__':
    imgpath=''
    jsonpahth=''
    outputpath=''
    jsons=os.listdir(jsonpahth)
    for js in jsons:
        image=Image.open(imgpath+js.split('.')[0]+'.jpg')
        points=[]
        with open(jsonpahth+js) as f:
            ann=json.load(f)
            for shape in ann['shapes']:
                if shape['label']=='grape':
                    point=shape['points']
                    points.append(point)
        points=np.array(points)
        points = np.vstack(points)
        dot_map=get_dot_map((image.size[1],image.size[0]),points).astype(np.uint8)
        dot_png=Image.fromarray(dot_map)
        dot_png.save(outputpath+js.split('.')[0]+'.png')