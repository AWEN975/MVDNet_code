import torch
import torch.nn as nn
import torch.nn.functional as F
from importlib import import_module
from misc import layer
from . import counters
import numpy as np
import pdb


class SegLoss(nn.Module):
    """
    loss：BCE Loss + Dice Loss
    """

    def __init__(self, weight_bce=1.0, weight_dice=1.0, smooth=1.0):

        super(SegLoss, self).__init__()
        self.weight_bce = weight_bce
        self.weight_dice = weight_dice
        self.smooth = smooth
        self.bce_loss = nn.BCEWithLogitsLoss()

    def forward(self, inputs, targets):

        targets = targets.float()

        bce_loss = self.bce_loss(inputs, targets)

        probs = torch.sigmoid(inputs)

        dims = (2, 3)
        intersection = torch.sum(probs * targets, dim=dims)
        cardinality = torch.sum(probs + targets, dim=dims)

        dice_score = (2. * intersection + self.smooth) / (cardinality + self.smooth)
        dice_loss = 1. - dice_score.mean()

        total_loss = self.weight_bce * bce_loss + self.weight_dice * dice_loss

        return total_loss

class AdaptiveWeightScheduler:
    def __init__(self, initial_weights, update_interval=100, alpha=0.9):
        self.weights = initial_weights
        self.update_interval = update_interval
        self.alpha = alpha
        self.loss_history = []
        self.step_count = 0

    def update_weights(self, current_losses):
        self.step_count += 1
        self.loss_history.append(current_losses)

        if self.step_count % self.update_interval == 0:

            recent_losses = np.array(self.loss_history[-self.update_interval:])
            avg_losses = np.mean(recent_losses, axis=0)
            loss_ratio = avg_losses / np.min(avg_losses)
            new_weights = 1.0 / loss_ratio
            self.weights = np.array(self.weights)
            new_weights = np.array(new_weights)
            self.weights = self.alpha * self.weights + (1 - self.alpha) * new_weights
            self.weights = self.weights / np.sum(self.weights) * len(self.weights)
            print(f"Updated weights: Density={self.weights[0]:.6f}, Mask={self.weights[1]:.6f}")

        return self.weights
class CrowdCounter(nn.Module):
    def __init__(self,gpus,model_name):
        super(CrowdCounter, self).__init__()    
        # pdb.set_trace()    
        ccnet =  getattr(getattr(counters, model_name), model_name)

        gs_layer = getattr(layer, 'Gaussianlayer')

        self.CCN = ccnet()
        self.gs = gs_layer()
        if len(gpus)>1:
            self.CCN = torch.nn.DataParallel(self.CCN, device_ids=gpus).cuda()
            self.gs = torch.nn.DataParallel(self.gs, device_ids=gpus).cuda()
        else:
            self.CCN = self.CCN.cuda()
            self.gs = self.gs.cuda()
        self.loss_mse_fn = nn.MSELoss().cuda()
        self.loss_mask=SegLoss()
        self.weight_scheduler = AdaptiveWeightScheduler(initial_weights=[1.0, 0.01])
    @property
    def loss(self):
        return self.loss_mse

    def forward(self, img, dot_map, mask_map):
        density_pred,mask_pred = self.CCN(img)
        gt_map = self.gs(dot_map)
        self.loss_dot_mse= self.build_loss(density_pred.squeeze(), gt_map.squeeze())
        self.loss_mask_mse = self.loss_mask(mask_pred, mask_map)
        weights = self.weight_scheduler.update_weights(
            [self.loss_dot_mse.item(), self.loss_mask_mse.item()]
        )
        self.loss_mse=weights[0]*self.loss_dot_mse+ weights[1]*self.loss_mask_mse
        return density_pred, mask_pred, gt_map, mask_map
    
    def build_loss(self, density_map, gt_data):
        loss_mse = self.loss_mse_fn(density_map, gt_data)
        return loss_mse

    def test_forward(self, img):                               
        density_map = self.CCN(img)                    
        return density_map

    def predict(self,img,dot_map, mask_map):
        density_pred, mask_pred = self.CCN(img)
        gt_map = self.gs(dot_map)
        return density_pred, mask_pred, gt_map, mask_map


