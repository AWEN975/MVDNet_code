#!/usr/bin/python
# -*- coding: utf-8 -*-
# @Time : 2024/5/5 10:56
# @Author : 'IReverser'
# @FileName: model_config.py


def mhsa(num_heads, key_dim, value_dim, px):
    if px == 24:
        kv_strides = 2
    elif px == 12:
        kv_strides = 1
    query_h_strides = 1
    query_w_strides = 1
    use_layer_scale = True
    use_multi_query = True
    use_residual = True
    return [
        num_heads, key_dim, value_dim, query_h_strides, query_w_strides, kv_strides,
        use_layer_scale, use_multi_query, use_residual
    ]



MNV4HybirdConvLarge_Block_Specs = {
    "conv0": {
        "block_name": "convbn",
        "num_blocks": 1,
        "block_specs": [
            [3, 24, 3, 2],  # in_channnels, out_channels, kernel_size, stride
        ]
    },
    "layer1": {
        "block_name": "fused_ib",
        "num_blocks": 1,
        "block_specs": [
            [24, 48, 2, 4.0, True],
        ]
    },
    "layer2": {
        "block_name": "uib",
        "num_blocks": 2,
        "block_specs": [
            [48, 96, 3, 3, True, 2, 4],
            [96, 96, 3, 3, True, 1, 4],
        ]
    },
    "layer3": {
        "block_name": "uib",
        "num_blocks": 2,
        "block_specs": [
            # in_channels, out_channels, start_dw_kernel_size, middle_dw_kernel_size, middle_dw_downsample, stride, expand_ratio, msha
            [96, 192, 3, 3, True, 1, 4],
            [192, 192, 3, 3, True, 1, 4],
        ]
    },
    "layer4": {
        "block_name": "uib",
        "num_blocks": 2,
        "block_specs": [
            [192, 512, 3, 3, True, 1, 4],
            [512, 512, 3, 3, True, 1, 4]],
    },

    "layer_last": {
        "block_name": "convbn",
        "num_blocks": 1,
        "block_specs": [
            [24, 1, 1, 1],

        ]
    }

}

MODEL_SPECS = {
    "MNV4HybridLarge": MNV4HybirdConvLarge_Block_Specs
}
if __name__ == '__main__':
    print(mhsa(8, 48, 48, 24))
    print(mhsa(4, 64, 64, 12))

























