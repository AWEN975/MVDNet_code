from . import CANNet
from . import MCNN
from . import VGG
from . import Res101_SFCN
from . import CSRNet
from . import SCAR
from . import VGG
from. import MobileNetV4